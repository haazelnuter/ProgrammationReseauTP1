package com.example.first_try;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.io.*;
import java.net.Socket;

public class ClientFX extends Application {
    PrintWriter pw ;
    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("Client Chat");
        BorderPane borderPane = new BorderPane();

        Label labelHost=new Label("Host :");
        TextField textFieldHost = new TextField("localhost");
        Label labelPort=new Label("Port :");
        TextField textFieldPort = new TextField("234");
        Button buttonConnecter=new Button("Connecter");
        HBox hbox =new HBox(); hbox.setSpacing(10); hbox.setPadding(new Insets(10));
        hbox.setBackground(new Background(new BackgroundFill(Color.DARKGRAY, null, null)));
        hbox.getChildren().addAll(labelHost,textFieldHost,labelPort,textFieldPort,buttonConnecter);
        borderPane.setTop(hbox);

        VBox vbox =new VBox(); vbox.setSpacing(10); vbox.setPadding(new Insets(10));
        ObservableList<String> listModel= FXCollections.observableArrayList();
        ListView<String> ListView=new ListView<String>(listModel);
        vbox.getChildren().add(ListView);
        borderPane.setCenter(vbox);

        Label labelMessage=new Label("Message :");
        TextField textFieldMessage = new TextField(); textFieldMessage.setPrefSize(300,30);
        Button buttonEnvoyer=new Button("Envoyer");
        HBox hbox2 =new HBox(); hbox2.setSpacing(10); hbox2.setPadding(new Insets(10));
        hbox2.setBackground(new Background(new BackgroundFill(Color.DARKGRAY, null, null)));
        hbox2.getChildren().addAll(labelMessage,textFieldMessage,buttonEnvoyer);
        borderPane.setBottom(hbox2);


        Scene scene=new Scene(borderPane,600,400);
        primaryStage.setScene(scene);
        primaryStage.show();

        buttonConnecter.setOnAction((evt)->{
            String host =textFieldHost.getText();
            int port = Integer.parseInt(textFieldPort.getText());
            try {
                Socket socket=new Socket(host,port);
                InputStream inputStream = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(inputStream);
                BufferedReader br = new BufferedReader(isr);
                OutputStream os = socket.getOutputStream();
                pw = new PrintWriter(os,true);

                new Thread(()->{

                    while(true) {
                        try {
                            String reponse=br.readLine();
                            Platform.runLater(()->{
                                listModel.add(reponse);
                            });
                        } catch (IOException e) {
                            e.printStackTrace();
                        }


                    }

                }).start();
            }
            catch (IOException e) {
                e.printStackTrace();
            }

        });

        buttonEnvoyer.setOnAction((evt)->{
            String message=textFieldMessage.getText();
            pw.println(message);

        });

    }

}