module com.example.first_try {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.first_try to javafx.fxml;
    exports com.example.first_try;
}