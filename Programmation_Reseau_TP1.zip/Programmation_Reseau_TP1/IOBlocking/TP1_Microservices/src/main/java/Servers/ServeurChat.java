package Servers;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
public class ServeurChat extends Thread {
    private int nombreClient;
    private List<Conversation> Clients = new ArrayList<Conversation>();

    public static void main(String[] args) {
        new ServeurChat().start();
        System.out.println("Demarrage du serveur ...");
    }

    @Override
    public void run() {
        try {
            ServerSocket ss = new ServerSocket(234);
            while (true) {
                Socket socket = ss.accept();
                ++nombreClient;
                Conversation conversation = new Conversation(socket, nombreClient);
                Clients.add(conversation);
                conversation.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    class Conversation extends Thread {
        protected Socket socket;
        protected int numeroClient;

        public Conversation(Socket s, int num) {
            this.socket = s;
            this.numeroClient = num;
        }

        public void broadcastMessage(String message, Socket soc, int num) {
            try {
                for (Conversation client : Clients) {
                    if (client.socket != soc) {
                        if (client.numeroClient == num || num == -1) {
                            PrintWriter PrintWriter = new PrintWriter(client.socket.getOutputStream(), true);
                            PrintWriter.println(message);
                        }
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        @Override
        public void run() {
            try {
                InputStream is = socket.getInputStream();
                InputStreamReader isr = new InputStreamReader(is);
                BufferedReader br = new BufferedReader(isr);

                OutputStream os = socket.getOutputStream();
                PrintWriter pw = new PrintWriter(os, true);
                String IP = socket.getRemoteSocketAddress().toString();
                System.out.println("Connexion du client numero :" + numeroClient + "IP = " + IP);
                pw.println("Bienvenu vous etes le client numero : " + numeroClient);
                while (true) {
                    String req = br.readLine();
                    if (req.contains("=>")) {
                        String[] requestParams = req.split("=>");
                        if (requestParams.length == 2) ;
                        String message = requestParams[1];
                        int numeroClient = Integer.parseInt(requestParams[0]);
                        broadcastMessage(message, socket, numeroClient);

                    } else {
                        broadcastMessage(req, socket, -1);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


