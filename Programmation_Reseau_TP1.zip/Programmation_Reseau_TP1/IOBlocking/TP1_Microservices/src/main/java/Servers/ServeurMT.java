package Servers;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class ServeurMT  extends Thread{
    private int nb_client;
    public static void main(String [] args){
        new ServeurMT().start();
        System.out.println("suite de l'application ...");
    }

    @Override
    public void run() {
        try {
            ServerSocket ss=new ServerSocket(1234);
            System.out.println("demarrage du server ...");
            while (true){
                Socket socket= ss.accept();
                ++nb_client;
                new Conversation(socket,nb_client).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    class Conversation extends Thread{
        private Socket socket;
        private  int nbclient;
        Conversation(Socket s,int num){
            this.socket=s; this.nbclient=num;
        }
        @Override
        public void run() {
            try {
                InputStream is= socket.getInputStream();
                InputStreamReader isr=new InputStreamReader(is);
                BufferedReader br=new BufferedReader(isr);
                OutputStream os=socket.getOutputStream();
                PrintWriter pw=new PrintWriter(os,true);
                System.out.println("connexion du client numero: "+nbclient);
                String IP=socket.getRemoteSocketAddress().toString();
                System.out.println("votre adress IP"+IP);
                pw.println("bien venue vous etes le client numero "+nbclient);
                while (true){
                    String rep=br.readLine();
                    System.out.println("le client"+IP+" a envoye une requete "+rep);
                    pw.println(rep.length());
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}

