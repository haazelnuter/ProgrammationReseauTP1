import socket

host = 'localhost'
port = 234
s = socket.socket()
s.connect((host, port))
while True:
    message = input('ME: ')
    s.sendall(message.encode())
    response = s.recv(1024).decode()
    print('Other: ', response)
    if message.lower() == 'exit':
        break
s.close()
