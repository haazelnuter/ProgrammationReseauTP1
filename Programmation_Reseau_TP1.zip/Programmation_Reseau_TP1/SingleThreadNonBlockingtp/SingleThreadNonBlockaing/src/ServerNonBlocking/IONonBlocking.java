package ServerNonBlocking;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

public class IONonBlocking {
        public static void main(String[] args) throws IOException {
            Selector selector = Selector.open();
            ServerSocketChannel serverSocketChannel = ServerSocketChannel.open(); // creer server
            serverSocketChannel.configureBlocking(false);
            serverSocketChannel.bind(new InetSocketAddress("0.0.0.0", 4444));
            //int validOps =serverSocketChannel.validOps();
            serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT); //Num de l'evenement possible
            while (true) {
                int channelCount = selector.select();
                if (channelCount == 0)// pas de request
                {
                    continue;
                }
                Set<SelectionKey> selectionKeys = selector.selectedKeys();
                Iterator<SelectionKey> iterator = selectionKeys.iterator();
                while (iterator.hasNext()) {
                    SelectionKey selectionKey = iterator.next();
                    if (selectionKey.isAcceptable())// request demande existe
                    {
                        handleAccepte(selectionKey, selector);
                    } else {
                        if (selectionKey.isReadable())// il ya qlq1 qui a envoye une requete
                        {
                            handleReadWrite(selectionKey, selector);
                        }
                    }
                }
                iterator.remove();
            }
        }


        private static void handleAccepte(SelectionKey selectionKey, Selector selector) throws IOException {
            ServerSocketChannel serverSocketChannel = (ServerSocketChannel) selectionKey.channel();
            SocketChannel socketChannel = serverSocketChannel.accept();
            socketChannel.configureBlocking(false); // !bloquant
            socketChannel.register(selector, selectionKey.OP_READ); //qlq1 envoye des donnees
            System.out.println(String.format("new connection from " + socketChannel.getRemoteAddress()));
        }

        private static void handleReadWrite(SelectionKey selectionKey, Selector selector) throws IOException {
            SocketChannel socketChannel = (SocketChannel) selectionKey.channel();
            //je lis la request et j'envoie le reponse
            //Buffers: des IO !bloquantes
            ByteBuffer byteBuffer = ByteBuffer.allocate(1024);
            int dataSize = socketChannel.read(byteBuffer); // return Nb of octets envoye
            if (dataSize == -1)// mode deconnecter
            {
                System.out.println(String.format("le client %s est deconnecter", socketChannel.getRemoteAddress()));
            }
            String request = new String(byteBuffer.array()).trim();
            System.out.println(String.format("new request %s from %s", request, socketChannel.getRemoteAddress()));
            String response = new StringBuffer(request).reverse().toString().toUpperCase();
            ByteBuffer byteBufferResponse = ByteBuffer.allocate(1024);
            //MODE ECRITURE
            byteBufferResponse.put(response.getBytes());// buffer peut etre en mode ecriture ou lecture
            //basculer d'un mode vers un mode , on utilise flip
            byteBufferResponse.flip();
            socketChannel.write(byteBufferResponse);// data exite in buffer , il doit etre passer vers channel , pour qu'il soit envoyer vers le client

        }
    }







